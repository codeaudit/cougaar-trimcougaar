/*
 *
 * Copyright 2008 by BBN Technologies Corporation
 *
 */

package org.cougaar.test.sequencer.experiment;

import org.cougaar.test.sequencer.Context;
import org.cougaar.test.sequencer.Report;
import org.cougaar.test.sequencer.WorkerPlugin;

/**
 *
 */
public class ExperimentWorkerPlugin extends WorkerPlugin<ExperimentStep, Report, Context> {

    protected void doStep(ExperimentStep step, Context context) {
        // TODO Auto-generated method stub
    }

}
