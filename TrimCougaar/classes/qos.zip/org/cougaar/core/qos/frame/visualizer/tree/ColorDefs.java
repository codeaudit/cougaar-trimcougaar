package org.cougaar.core.qos.frame.visualizer.tree;

import java.awt.*;

/**
 * Created by IntelliJ IDEA.
 * User: mwalczak
 * Date: Apr 27, 2005
 * Time: 2:56:34 PM
 * To change this template use File | Settings | File Templates.
 */
public class ColorDefs {

    public static Color inheritedSlotColor = new Color(228, 205, 126);
    public static Color localSlotColor     = Color.white;
    public static Color slotDefinitionColor = new Color(255,242,171);

}
